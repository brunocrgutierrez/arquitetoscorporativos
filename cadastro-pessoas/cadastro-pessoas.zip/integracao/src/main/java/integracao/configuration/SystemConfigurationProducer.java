package integracao.configuration;

import integracao.annotation.SystemConfigurationClass;

import java.lang.reflect.Field;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

import br.gov.frameworkdemoiselle.annotation.Name;


public class SystemConfigurationProducer {

	
	@SuppressWarnings({ "rawtypes" })
	@Produces
	@SystemConfigurationClass
	public AbstractSystemConfiguration criar(InjectionPoint ip) {
		
		AbstractSystemConfiguration retorno = null;
		try {
				
			SystemConfigurationClass annotationSystemConfigurationClass = ip.getAnnotated().getAnnotation(SystemConfigurationClass.class);
			
			if (annotationSystemConfigurationClass != null){
			
						
					Class classeConfiguracaoPropriedadesAmbiente = annotationSystemConfigurationClass.configurationClass();
					
					if(!classeConfiguracaoPropriedadesAmbiente.equals(AbstractSystemConfiguration.class)){
						
						retorno = (AbstractSystemConfiguration) classeConfiguracaoPropriedadesAmbiente.newInstance();
						
						
						
						Field[] fields = retorno.getClass().getDeclaredFields();
						if (fields != null){
								
								for (Field field : fields){
									
									String propertyName = null;
									
									field.setAccessible(true);
									Name annotationPropertyName = field.getAnnotation(Name.class);
									if (annotationPropertyName != null){
										propertyName = annotationPropertyName.value();
									} else {
										propertyName = field.getName();
									}
									
									if (propertyName != null){
										field.set(retorno, System.getProperty(propertyName));
									}
									
								}
								
						}
						
					}

						
				}
				
			
		} catch (Exception e){
			e.printStackTrace();
		}
		
		return retorno;
	}
	
}
