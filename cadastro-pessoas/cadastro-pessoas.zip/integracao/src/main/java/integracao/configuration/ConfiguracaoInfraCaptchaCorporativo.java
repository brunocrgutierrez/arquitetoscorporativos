package integracao.configuration;

import corporativo.servicos.interfaces.ItfConfiguracaoInfraCaptchaCorporativo;


public class ConfiguracaoInfraCaptchaCorporativo implements ItfConfiguracaoInfraCaptchaCorporativo {

	public String getUrlServicoValidar() {
		return System.getProperty("serpro.gov.br.corporativo.captcha.servicos.validar.url");
	}

}
