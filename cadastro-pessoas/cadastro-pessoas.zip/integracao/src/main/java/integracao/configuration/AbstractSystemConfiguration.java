package integracao.configuration;

import javax.enterprise.context.RequestScoped;

@RequestScoped
public class AbstractSystemConfiguration {

}
