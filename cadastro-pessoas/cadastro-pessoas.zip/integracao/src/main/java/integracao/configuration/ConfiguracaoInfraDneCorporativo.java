package integracao.configuration;

import corporativo.servicos.interfaces.ItfConfiguracaoInfraDneCorporativo;


public class ConfiguracaoInfraDneCorporativo implements ItfConfiguracaoInfraDneCorporativo {

	public String getTrustStore() {
		return System.getProperty("javax.net.ssl.trustStore");
	}

	public String getTrustStorePassword() {
		return System.getProperty("javax.net.ssl.trustStorePassword");
	}

	public String getDneUrl() {
		return System.getProperty("serpro.gov.br.corporativo.dne.servicos.buscarCep.url");
	}


}
