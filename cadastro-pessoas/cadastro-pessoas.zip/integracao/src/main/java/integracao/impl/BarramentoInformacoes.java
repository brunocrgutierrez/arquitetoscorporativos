package integracao.impl;

import java.util.List;

import corporativo.servicos.interfaces.ItfBarramentoInformacoes;

public class BarramentoInformacoes implements ItfBarramentoInformacoes
{
	public List<Object> listar() throws Throwable
	{
		// TODO Auto-generated method stub
		return null;
	}
}
