package integracao.impl;

import java.util.List;

import javax.enterprise.inject.spi.BeanManager;
import javax.inject.Inject;

import br.gov.serpro.sc.sms.ws.Credenciais;
import br.gov.serpro.sc.sms.ws.ErroSMS;
import br.gov.serpro.sc.sms.ws.Mensagem;
import br.gov.serpro.sc.sms.ws.Mensagem.Destinatarios;
import br.gov.serpro.sc.sms.ws.MensagemAfetadaErro;
import br.gov.serpro.sc.sms.ws.ObjectFactory;
import br.gov.serpro.sc.sms.ws.ReciboEnvio;
import br.gov.serpro.sc.sms.ws.RelatorioRecepcao;
import br.gov.serpro.sc.sms.ws.SmsHeader;
import br.gov.serpro.sc.sms.ws.client.MensagemSMSClient;
import br.gov.serpro.sc.sms.ws.client.MensagemSMSException;
import br.gov.serpro.sc.sms.ws.client.ServiceClientFactory;
import corporativo.servicos.interfaces.ItfConfiguracaoInfraEnvioSms;
import corporativo.servicos.interfaces.ItfEnvioSMS;

public class EnvioSMS implements ItfEnvioSMS
{

	@Inject 
	private BeanManager bm;
	
	@Inject
	private ItfConfiguracaoInfraEnvioSms configuracaoInfraSms;

	public void enviarSMS(List<String> lDestinatarios, String textoMensagem, String chaveCliente)
	{
		try
		{
            // Criar a fábrica de objetos do serviço.
            ObjectFactory objFactory = new ObjectFactory();

            // Criar uma mensagem.
            Mensagem mensagem = objFactory.createMensagem();
            mensagem.setTexto(textoMensagem);

            // Criar uma lista com 1 ou mais destinatários.
            Destinatarios destinatarios = objFactory.createMensagemDestinatarios();
            
            for (String destinatario : lDestinatarios)
            {
	            destinatarios.getDestinatario().add(destinatario);
            }
            // ...

            // Associa a lista de destinatários a mensagem.
            mensagem.setDestinatarios(destinatarios);

            // Criar as credenciais usadas pelo cliente do serviço.
            Credenciais credencias = objFactory.createCredenciais();
            credencias.setIdCliente(Integer.valueOf(chaveCliente));
            credencias.setChaveAcesso(configuracaoInfraSms.getChaveAcesso());

            // Atribuir as credenciais ao header SMS.
            SmsHeader smsHeader = objFactory.createSmsHeader();
            smsHeader.setCredenciais(credencias);

            // Criar o cliente.
            MensagemSMSClient clienteServico = ServiceClientFactory.createMensagemSMSClient(configuracaoInfraSms.getEndPointEnvioSms());        

            // Invocar o serviço.
            RelatorioRecepcao relatorio = clienteServico.enviar(mensagem, smsHeader);

            // Processar o retorno do serviço.
            processarRelatorioRecepcao(relatorio);

        }
		
		catch (MensagemSMSException e)
		{
            tratarMensagemSMSException(e);
        }
	}
	
	private void tratarMensagemSMSException(MensagemSMSException e) {
        String codigoErro = e.getErrorCode();
        String mensagemErro = e.getMessage();
        if ("<um_código>".equals(codigoErro)) {
            // ação 1.
        } else if ("<outro_código>".equals(codigoErro)) {
            // ação 2.
        } // ...
        else {
            // ação n
            System.err.println("Código de erro....: " + codigoErro);
            System.err.println("Mensagem de erro..: " + mensagemErro);
            e.printStackTrace();
        }
    }	
	
	private void processarRelatorioRecepcao(RelatorioRecepcao relatorio)
	{
		RelatorioRecepcao.Recibos recibos = relatorio.getRecibos();
		
		if (recibos != null && !recibos.getRecibo().isEmpty())
		{
		      System.out.println("+========================================================+");
		      System.out.println("+       MENSAGENS RECEBIDAS C/ SUCESSO PELO SERVIÇO      +");
		      System.out.println("+========================================================+");
		      
		      for (ReciboEnvio r : recibos.getRecibo())
		      {
		          System.out.println("ID Mensagem......: " + r.getIdMensagem());
		          System.out.println("Posição no lote..: " + r.getPosicaoMensagemLote());
		          System.out.println("Destinatário.....: " + r.getDesinatario());
		          System.out.println("Recebida em......: " + r.getDataHoraRecebimento());
		          System.out.println("----------------------------------------------------------");
		      }
		 }

		 RelatorioRecepcao.Erros erros = relatorio.getErros();
		 
		 if (erros != null && !erros.getErro().isEmpty())
		 {
		      System.out.println("+========================================================+");
		      System.out.println("+             ERROS RETORNADOS PELO SERVIÇO              +");
		      System.out.println("+========================================================+");
		      
		      for (ErroSMS erro : erros.getErro())
		      {
		           System.out.println("Código.....................: " + erro.getCodigo());
		           System.out.println("Descrição..................: " + erro.getDescricao());
		           System.out.println("MENSAGENS AFETADAS");
		           
		           for (MensagemAfetadaErro m : erro.getMensagens().getMensagem())
		           {
		        	   System.out.println("  Posição no lote..........: " + m.getPosicaoLote());
		        	   
		        	   for (String d : m.getDestinatariosAfetados().getDestinatario())
		        	   {
		        		   System.out.println("    Destinatário...........: " + d);
		        	   }
		           }
		           
		           System.out.println("----------------------------------------------------------");
		      }
		 }
	}
}
