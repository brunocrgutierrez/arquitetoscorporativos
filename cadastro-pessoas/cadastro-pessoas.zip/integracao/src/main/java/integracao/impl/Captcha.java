package integracao.impl;

import java.net.HttpURLConnection;
import java.net.URL;

import javax.enterprise.inject.spi.BeanManager;
import javax.inject.Inject;

import corporativo.excecoes.CaptchaInvalidoException;
import corporativo.excecoes.CaptchaServicoIndisponivelException;
import corporativo.servicos.interfaces.ItfCaptchaCorporativo;
import corporativo.servicos.interfaces.ItfConfiguracaoInfraCaptchaCorporativo;

public class Captcha implements ItfCaptchaCorporativo
{
	
	@Inject 
	private BeanManager bm;
	
	@Inject
	private ItfConfiguracaoInfraCaptchaCorporativo configuracaoInfraCaptcha;
	
	public boolean validarCaptcha(String token, String texto, String chaveCliente) throws Throwable
	{		

		String respostaTexto;
		
		URL url;
		
        HttpURLConnection con;
        
        url = new java.net.URL(configuracaoInfraCaptcha.getUrlServicoValidar());
        
        con = (java.net.HttpURLConnection)url.openConnection();
        con.setRequestMethod("POST");
        con.setDoOutput(true);
        
        java.io.DataOutputStream wr = new java.io.DataOutputStream(con.getOutputStream());
        
        wr.writeBytes(chaveCliente + "&" + token + "&" + texto);
        wr.flush();
        wr.close();

        if (con.getResponseCode() == 200)
        {            
        	java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(con.getInputStream()));
        	
            String inputLine;
            
            StringBuffer respostaBuffer = new StringBuffer();
            
            while ((inputLine = in.readLine()) != null)
            {
                respostaBuffer.append(inputLine);
            }
            
            in.close();
            
            respostaTexto = respostaBuffer.toString();
            
            if (respostaTexto.equals("0") || respostaTexto.equals("-1"))
            {
            	throw new CaptchaInvalidoException("Texto informado difere da imagem");
            }
            
            else if (respostaTexto.equals("2"))
            {
            	throw new CaptchaInvalidoException("Token da aplicação não localizado");
            }
        }
        
        else
        {
        	throw new CaptchaServicoIndisponivelException();
        }
        
		return true;		
	}
}
