package br.gov.serpro.cadastro.servicos.body;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import br.gov.serpro.cadastro.dominio.entity.Endereco;
import br.gov.serpro.cadastro.dominio.entity.Pessoa;
import br.gov.serpro.cadastro.dominio.entity.Telefone;

public class PessoaBody {
	
	private Long id;

	@Size(min = 1, message = "{required.field}")
	private String nome;
	
	@Pattern(regexp = "^\\d{8}$", message = "{cep.limite}")
	private String cep;
	
	@Size(min = 1, message = "{required.field}")
	private String logradouro;

	@Pattern(regexp = "^\\d{8,13}$", message = "{telefone.limite}")
	private String celular;
	
	
	private String token_captcha;
	
	private String texto_captcha;
	
	public PessoaBody(Pessoa pessoa) {
		
		if (pessoa != null){
			this.id = pessoa.getId();
			this.nome = pessoa.getNome();
			this.celular = pessoa.getTelefone() != null ? pessoa.getTelefone().getNumero() : null;
			this.logradouro = pessoa.getEndereco() != null ? pessoa.getEndereco().getLogradouro() : null;
			this.cep = pessoa.getEndereco() != null ? pessoa.getEndereco().getCep() : null;
		}
	}

	public Pessoa toEntity() {
		
		Pessoa pessoa = new Pessoa();
		pessoa.setId(this.id);
		pessoa.setNome(this.nome);
		
		Telefone telefone = new Telefone();
		telefone.setNumero(this.celular);
		pessoa.setTelefone(telefone);
		
		Endereco endereco = new Endereco();
		endereco.setCep(this.cep);
		endereco.setLogradouro(this.logradouro);

		pessoa.setEndereco(endereco);

		return pessoa;
	}
	
	public PessoaBody() {
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public String getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
	public String getCelular() {
		return celular;
	}
	public void setCelular(String celular) {
		this.celular = celular;
	}
	
	public String getToken_captcha() {
		return token_captcha;
	}

	public void setToken_captcha(String token_captcha) {
		this.token_captcha = token_captcha;
	}

	public String getTexto_captcha() {
		return texto_captcha;
	}

	public void setTexto_captcha(String texto_captcha) {
		this.texto_captcha = texto_captcha;
	}
	
	

	
}
