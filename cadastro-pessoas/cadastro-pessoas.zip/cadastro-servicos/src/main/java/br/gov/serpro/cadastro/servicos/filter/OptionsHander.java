package br.gov.serpro.cadastro.servicos.filter;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.jboss.resteasy.spi.DefaultOptionsMethodException;


/*
 * catch-all implementation of Cross-Origin Resource Sharing headers.
 *
 * Thanks to: Rajshekhar AndalaPisharam @ redhat for suggestion
 *
 * TODO: this is far too permissive
 *
 * good CORS explanation here
 *
 * https://developer.mozilla.org/en-US/docs/HTTP/Access_control_CORS
 *
 */
@Provider
public class OptionsHander implements
		ExceptionMapper<DefaultOptionsMethodException> 
{
	
	
	private static final String ACCESS_CONTROL_ALLOW_HEADERS = "Access-Control-Allow-Headers";
	private static final String ACCESS_CONTROL_ALLOW_METHODS = "Access-Control-Allow-Methods";
	private static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";
	private static final String ACCESS_CONTROL_ALLOW_ORIGIN_ANYONE = "*";
	
	@Context
	HttpHeaders httpHeaders;

	@Override
	public Response toResponse(DefaultOptionsMethodException exception) {
		final ResponseBuilder response = Response.ok();

		response.header(ACCESS_CONTROL_ALLOW_ORIGIN,
				ACCESS_CONTROL_ALLOW_ORIGIN_ANYONE);
		response.header(ACCESS_CONTROL_ALLOW_METHODS,"POST, GET, HEAD, OPTIONS, DELETE, PUT");
		response.header(ACCESS_CONTROL_ALLOW_HEADERS,"charset, connection, host, accept-language, user-agent, pragma, cache-control, content-length, accept-encoding, deflate, referer, Authorization, Origin, Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
		
		return response.build();
	}
}
