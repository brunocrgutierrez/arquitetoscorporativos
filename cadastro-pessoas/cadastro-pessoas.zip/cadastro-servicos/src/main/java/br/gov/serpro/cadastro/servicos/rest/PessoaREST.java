package br.gov.serpro.cadastro.servicos.rest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.net.URI;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import br.gov.frameworkdemoiselle.BadRequestException;
import br.gov.frameworkdemoiselle.NotFoundException;
import br.gov.frameworkdemoiselle.security.LoggedIn;
import br.gov.frameworkdemoiselle.transaction.Transactional;
import br.gov.frameworkdemoiselle.util.Beans;
import br.gov.frameworkdemoiselle.util.Strings;
import br.gov.frameworkdemoiselle.util.ValidatePayload;
import br.gov.serpro.cadastro.dominio.business.PessoaBC;
import br.gov.serpro.cadastro.dominio.entity.Pessoa;
import br.gov.serpro.cadastro.servicos.body.PessoaBody;
import br.gov.serpro.cadastro.servicos.configuration.ConfiguracoesCaptcha;
import corporativo.servicos.interfaces.ItfCaptchaCorporativo;

@Api(value = "pessoa")
@Path("pessoa")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PessoaREST {

	@Inject
	private PessoaBC bc;

	@Inject
	private ConfiguracoesCaptcha configuracoesCaptcha;
	
	@POST
	@LoggedIn
	@Transactional
	@ValidatePayload
	@ApiOperation(value = "Insere pessoa", response = Response.class)	
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Erro nos parâmetros informados") })
	public Response insert(PessoaBody body, @Context UriInfo uriInfo) throws Throwable {

		ItfCaptchaCorporativo captchaCorporativo = Beans.getReference(ItfCaptchaCorporativo.class);	
		captchaCorporativo.validarCaptcha(body.getToken_captcha(), body.getTexto_captcha(), configuracoesCaptcha.getChaveCliente());
			
		checkId(body);
			
		String id = bc.insert(body.toEntity()).getId().toString();
		URI location = uriInfo.getRequestUriBuilder().path(id).build();
	
		return Response.created(location).entity(id).build();
	}
	
	@GET	
	@ApiOperation(value = "Busca pessoa pelo nome", notes = "Se não for informado o parâmetro, serão retornados todos os registros", response = Pessoa.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Parâmetro em desacordo com a especificação.") })
	public List<Pessoa> find(@ApiParam(value = "nome da pessoa") @QueryParam("q") String query) throws Exception {
		List<Pessoa> result;

		if (Strings.isEmpty(query)) {
			result = bc.findAll();
		} else {
			result = bc.find(query);
		}

		return result;
	}

	@GET
	@Path("{id}")
	@ApiOperation(value = "Busca pessoa pelo id", notes = "É obrigatório informar o parâmetro", response = PessoaBody.class)	
	@ApiResponses(value = { @ApiResponse(code = 400, message = "É obrigatório informar o parâmetro") })
	public PessoaBody load(@ApiParam(value = "id da pessoa") @PathParam("id") Long id) throws Exception {
		Pessoa result = bc.load(id);

		if (result == null) {
			throw new NotFoundException();
		}
		
		return new PessoaBody(result);
	}

	
	@PUT
	@Path("{id}")
	@Transactional
	@LoggedIn
	@ValidatePayload
	@ApiOperation(value = "Atualiza pessoa pelo id", notes = "É obrigatório informar o parâmetro", response = Response.class)	
	@ApiResponses(value = { @ApiResponse(code = 400, message = "É obrigatório informar o parâmetro") })
	public Response update(@ApiParam(value = "id da pessoa", required=true) @PathParam("id") Long id, PessoaBody body) throws Exception {
		
		checkId(body);
		load(id);

		body.setId(id);
		Pessoa entity = bc.update(body.toEntity());
		
		if (entity == null) {
			return Response.status(Status.NOT_FOUND).build();
		} else {
			return Response.ok().build();
		}
	}

	@DELETE
	@LoggedIn
	@Path("{id}")
	@Transactional
	@ApiOperation(value = "Exclui pessoa pelo id", notes = "É obrigatório informar o parâmetro")	
	@ApiResponses(value = { @ApiResponse(code = 400, message = "É obrigatório informar o parâmetro") })
	public void delete(@ApiParam(value = "id da pessoa", required=true) @PathParam("id") Long id) throws Exception {
		load(id);
		bc.delete(id);
	}

	private void checkId(PessoaBody entity) throws Exception {
		if (entity.getId() != null) {
			throw new BadRequestException();
		}
	}
	
}
