package br.gov.serpro.cadastro.servicos.rest;

import javax.inject.Inject;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import corporativo.servicos.interfaces.ItfDNECorporativo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api(value="dne")
@Path("dne")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class DneREST {

	@Inject
	private ItfDNECorporativo dne;

	@GET
	@Path("{cep}")
	@ApiOperation(value="Busca endereço a partir do CEP", response=Response.class)
	public Response buscarCEP(@ApiParam(value="Número do CEP") @PathParam("cep") String cep, @ApiParam(value="Chave de acesso ao serviço corporativo DNE") @QueryParam("chave") String chaveCliente) throws Throwable {

		String retorno = dne.buscarDadosCEP(cep,chaveCliente);
		
		return Response.status(Status.OK).entity(retorno).build();
	}

	
	
}
