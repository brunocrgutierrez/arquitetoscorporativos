package br.gov.serpro.cadastro.servicos.loader;

import javax.inject.Inject;

import br.gov.frameworkdemoiselle.lifecycle.Startup;
import br.gov.frameworkdemoiselle.transaction.Transactional;
import br.gov.serpro.cadastro.dominio.entity.Endereco;
import br.gov.serpro.cadastro.dominio.entity.Pessoa;
import br.gov.serpro.cadastro.dominio.entity.Telefone;
import br.gov.serpro.cadastro.dominio.persistence.PessoaDAO;
 
@Transactional
public class Loader {
 
    @Inject
    private PessoaDAO pessoaDAO;
 
    @Startup
    public void load() {
        Pessoa pessoa;
 
        pessoa = new Pessoa();
        pessoa.setNome("John Malkovich");
        
        Endereco endereco = new Endereco();
        endereco.setCep("66077830");
        endereco.setLogradouro("Av. Perimetral, 2010");
        pessoa.setEndereco(endereco);
        
        Telefone telefone = new Telefone();
        telefone.setNumero("71 12345678");
        pessoa.setTelefone(telefone);
        
        pessoaDAO.insert(pessoa);
 
        pessoa = new Pessoa();
        pessoa.setNome("Cleverson Sacramento");

        endereco = new Endereco();
        endereco.setCep("67120555");
        endereco.setLogradouro("Av. José Malcher, 588");
        pessoa.setEndereco(endereco);
        
        telefone = new Telefone();
        telefone.setNumero("91 12345577");
        pessoa.setTelefone(telefone);
        
        pessoaDAO.insert(pessoa);
 
        pessoa = new Pessoa();
        pessoa.setNome("Luciano Borges");

        endereco = new Endereco();
        endereco.setCep("65077710");
        endereco.setLogradouro("Av. Almirante Barroso, 444");
        pessoa.setEndereco(endereco);
        
        telefone = new Telefone();
        telefone.setNumero("91 30354477");
        pessoa.setTelefone(telefone);
        
        pessoaDAO.insert(pessoa);
    }
}
