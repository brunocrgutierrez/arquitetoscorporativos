package br.gov.serpro.cadastro.servicos.rest;

import io.swagger.annotations.Info;
import io.swagger.annotations.SwaggerDefinition;
import io.swagger.jaxrs.config.BeanConfig;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@SwaggerDefinition(
		info = @Info(description = Api.DESCRIPTION, title = "Aplicação Exemplo de Cadastro de Pessoas", version = "1.0.0-SNAPSHOT") , 
		consumes = {"application/json" }, 
		produces = { "application/json" }, 
		schemes = { SwaggerDefinition.Scheme.HTTP, SwaggerDefinition.Scheme.HTTPS })
@ApplicationPath("api")
public class Api extends Application {
	
	public static final String DESCRIPTION = "As `APIs de Cadastro de Pessoas` são serviços que estão expostos através de `HTTP REST` oferecendo operações e buscas nos dados pertencentes à Aplicação Exemplo de Cadastro de Pessoas.";

	public Api() {
		BeanConfig beanConfig = new BeanConfig();
		beanConfig.setVersion("1.0.0-SNAPSHOT");
		beanConfig.setHost("localhost:8080");
		beanConfig.setBasePath("/cadastro-servicos/api");
		beanConfig.setResourcePackage("br.gov.serpro.cadastro.servicos.rest");
		beanConfig.setScan(true);
	}

}
