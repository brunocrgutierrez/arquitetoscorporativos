package br.gov.serpro.cadastro.servicos.configuration;

import br.gov.frameworkdemoiselle.annotation.Name;
import br.gov.frameworkdemoiselle.configuration.Configuration;

@Configuration(resource="configuracoescaptcha")
public class ConfiguracoesCaptcha {

	@Name(value="chave.cliente")
	private String chaveCliente;

	public String getChaveCliente() {
		return chaveCliente;
	}
}
