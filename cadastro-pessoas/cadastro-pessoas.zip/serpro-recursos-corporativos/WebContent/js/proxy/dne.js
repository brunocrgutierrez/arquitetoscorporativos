var urlDne = '';

if (ConfiguracoesServicosCorporativos.dneEnvironment == 'dsn'){
	//urlDne = 'http://10.32.96.129:8080/cadastro-servicos/dne/';//'https://desdne.servicoscorporativos.serpro/dne/v1/ceps/';
	urlDne = 'https://desdne.servicoscorporativos.serpro/dne/v1/ceps/';
} else if (ConfiguracoesServicosCorporativos.dneEnvironment == 'hom'){
	urlDne = 'https://dne.servicoscorporativos.serpro/';
} else if (ConfiguracoesServicosCorporativos.dneEnvironment == 'prod'){
	urlDne = 'https://dne.servicoscorporativos.serpro/';
}

var DNEProxy = 
{
	url: urlDne,
	load: function(cep)
	{
		return $.ajax
		(
			{
				type: "GET",
				
				url: this.url + cep+ "?chave="+ConfiguracoesServicosCorporativos.dneClientId,
				
				dataType : "json",
				
				beforeSend: function(jqXHR)
				{
					App.auth.setHeader(jqXHR);
				}
			}
		);
	}
};