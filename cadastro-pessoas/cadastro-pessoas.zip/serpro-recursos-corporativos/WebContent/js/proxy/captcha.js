function encontrarDIVPorAtributo(elementoPai, atributo){
        var elementoItem;

        if (document.querySelectorAll){
            listaElementos = document.querySelectorAll("[" + atributo + "]");
            if (listaElementos.length > 0){
                return listaElementos[0];
            }
        }
        else{
            for (var i = 0; i < elementoPai.length; i++) {
                elementoItem = elementoPai[i];
                if (elementoItem.nodeType === 1){
                    if (elementoItem.getAttribute(atributo) || (elementoItem.getAttribute(atributo) === "")) {
                        return elementoItem;
                    }
                    else{
                        if ((elementoItem.childNodes) && (elementoItem.childNodes.length > 0)){
                            elementoItem = encontrarDIVPorAtributo(elementoItem.childNodes, atributo);
                            if (elementoItem){
                                return elementoItem;
                            }
                        }
                    }
                }
            }
        }
    }


elemento = encontrarDIVPorAtributo(document.body.childNodes, 'data-ui-captcha-serpro');
if (elemento){
	elemento.setAttribute('data-clienteid',ConfiguracoesServicosCorporativos.captchaClientId);
}


var urlCaptcha = '';

if (ConfiguracoesServicosCorporativos.captchaEnvironment == 'dsn' || ConfiguracoesServicosCorporativos.captchaEnvironment == 'hom'){
	urlCaptcha = 'http://homcaptcha.servicoscorporativos.serpro.gov.br';
}

if (ConfiguracoesServicosCorporativos.captchaEnvironment == 'prodbsa'){
	urlCaptcha = 'http://captcha.servicoscorporativos.serpro.gov.br';
}

if (ConfiguracoesServicosCorporativos.captchaEnvironment == 'prodsp'){
	urlCaptcha = 'http://captcha2.servicoscorporativos.serpro.gov.br';
}
document.write('<script type="text/javascript" src="'+urlCaptcha+'/js/captcha.serpro.gov.br.js"></script>');


