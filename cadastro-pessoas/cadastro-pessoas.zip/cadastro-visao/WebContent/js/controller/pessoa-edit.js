$(function() {
	$("#delete").hide();
	$("#nome").focus();

	if (id = App.getUrlParameterByName('id')) {
		PessoaProxy.load(id).done(loadOk).fail(loadFail);
	}

	MetadataProxy.getDemoiselleVersion().done(function(data) {
		$("#demoiselle-version").html(data);
	});

	$("form").submit(function(event) {
		event.preventDefault();
	});

	$("#save").click(function() {
		var data = {
			nome : $("#nome").val(),
			logradouro : $("#logradouro").val(),
			cep : $("#cep").val(),
			celular: $("#celular").val(),
			token_captcha:$("#txtToken_captcha_serpro_gov_br").val().trim(),
			texto_captcha:$("#txtTexto_captcha_serpro_gov_br").val().trim()
		};

		if (id = $("#id").val()) {
			PessoaProxy.update(id, data).done(saveOk).fail(saveFail);
		} else {
			PessoaProxy.insert(data).done(saveOk).fail(saveFail);
		}
	});

	$("#delete").click(function() {
		bootbox.confirm("Tem certeza que deseja apagar?", function(result) {
			if (result) {
				PessoaProxy.remove([ $("#id").val() ]).done(removeOk);
			}
		});
	});

	$("#back").click(function() {
		history.back();
	});
});

function loadOk(data) {
	$("#id-row").show();
	$("#id-text").html(data.id);
	$("#id").val(data.id);
	$("#nome").val(data.nome);
	$("#logradouro").val(data.logradouro);
	$("#cep").val(data.cep);
	$("#celular").val(data.celular);
	$("#txtTexto_captcha_serpro_gov_br").val('');
	$("#delete").show();
}

function loadFail(jqXHR) {
	switch (jqXHR.status) {
		case 404:
			bootbox.alert("Você está tentando acessar um registro inexistente!", function() {
				location.href = "pessoa-list.html";
			});
			break;

		default:
			break;
	}
}

function saveOk() {
	location.href = 'pessoa-list.html';
}

function saveFail(jqXHR) {
	switch (jqXHR.status) {
			case 422:
			$($("form input").get().reverse()).each(function() {
				var id = $(this).attr('id');
				var message = null;

				$.each(jqXHR.responseJSON, function(index, value) {
					if (id == value.property) {
						message = value.message;
						return;
					}
				});

				if (message) {
					$("#" + id + "-message").html(message).show();
					$(this).focus();
				} else {
					$("#" + id + "-message").hide();
				}
			});
			break;

		default:
			break;
	}
}

function removeOk() {
	location.href = 'pessoa-list.html';
}
