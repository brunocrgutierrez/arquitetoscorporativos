$(function()
{
	$("#loadCEPData").click(function()
	{
		var cep = "";
		
		cep = $("#cep").val();
		
		DNEProxy.load(cep).done(getCEPData);			
	});
	
	function getCEPData(data)
	{	
		var conteudo = "";
		
		conteudo = data.hits.hits[0]._source.tlo_tx;
		conteudo +=  " " + data.hits.hits[0]._source.log_no;
		conteudo +=  " " + "[Numero],";
		conteudo +=  " " + data.hits.hits[0]._source.bai_no_ini+",";
		conteudo +=  " " + data.hits.hits[0]._source.loc_no+",";
		conteudo +=  " " + data.hits.hits[0]._source.ufe_sg;
			

		//{"hits":{"hits":[{"_id":"d4d55de3e58e8c687738e91fba6789c8","_source":{"@timestamp":"2015-09-17T03:00:00.000Z","subtipo":"D","ufe_sg":"PA","loc_nu":"00004565","loc_no":"Belém","bai_no_ini":"Umarizal","bai_no_fim":"","tlo_tx":"Rua","prep":"","tit_pat":"","log_nu":"00162859","log_no":"Ferreira Pena","log_no_abrev":"R Ferreira Pena","inf_adi":"","cep":"66050140","gra_usu":"N","log_ativ":"S","tipo":"logradouro","versao_dados":"V1509"}}]}}
		$("#logradouro").val(conteudo);		
	}
});