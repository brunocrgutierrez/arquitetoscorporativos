var MetadataProxy = {

	url : "cadastro-servicos-0.0.1-SNAPSHOT/api/metadata",

	getVersion : function() {
		return $.ajax({
			type : "GET",
			url : this.url + "/version"
		});
	},

	getMessage : function(key) {
		return $.ajax({
			type : "GET",
			url : this.url + "/message/" + key
		});
	},

	getDemoiselleVersion : function() {
		return $.ajax({
			type : "GET",
			url : this.url + "/demoiselle/version"
		});
	}
};
