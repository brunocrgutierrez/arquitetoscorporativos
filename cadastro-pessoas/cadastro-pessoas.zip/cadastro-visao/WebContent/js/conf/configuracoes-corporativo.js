var ConfiguracoesServicosCorporativos = {
	// Indique o ambiente do serviço corporativo que será utilizado e chave do serviço
	captchaEnvironment : 'dsn',
	captchaClientId : '2f25229f8f8043609907d747630a55ce',
	dneEnvironment : 'dsn',
	dneClientId : '8da9e3be-2a0b-4f23-8ec7-cf629faffa42'
};