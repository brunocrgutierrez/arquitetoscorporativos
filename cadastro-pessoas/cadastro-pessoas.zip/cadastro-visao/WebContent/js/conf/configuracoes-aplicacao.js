var Configuracoes = {

	urlPessoaProxy : "http://localhost:8080/cadastro-servicos-0.0.1-SNAPSHOT/api/pessoa"
};