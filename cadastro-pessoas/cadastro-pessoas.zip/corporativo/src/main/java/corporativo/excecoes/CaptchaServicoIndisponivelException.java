package corporativo.excecoes;

public class CaptchaServicoIndisponivelException extends Throwable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6372297796922284665L;

}
