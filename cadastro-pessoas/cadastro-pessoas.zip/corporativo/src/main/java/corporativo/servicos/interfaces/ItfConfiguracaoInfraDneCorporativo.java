package corporativo.servicos.interfaces;

public interface ItfConfiguracaoInfraDneCorporativo {
	
	public String getTrustStore();
	public String getTrustStorePassword();
	public String getDneUrl();
}
