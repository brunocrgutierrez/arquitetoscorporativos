package corporativo.servicos.interfaces;

public interface ItfDNECorporativo
{
    public String buscarDadosCEP(String cep, String chaveCliente) throws Throwable;
}