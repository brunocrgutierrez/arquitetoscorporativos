package corporativo.servicos.interfaces;

import java.util.List;

public interface ItfBarramentoInformacoes
{	
	public List<Object> listar() throws Throwable;
}
