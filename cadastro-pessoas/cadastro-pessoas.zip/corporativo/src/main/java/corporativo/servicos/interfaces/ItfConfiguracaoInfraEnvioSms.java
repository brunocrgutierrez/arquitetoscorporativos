package corporativo.servicos.interfaces;

public interface ItfConfiguracaoInfraEnvioSms {
	
	public String getEndPointEnvioSms();
	public String getChaveAcesso();
}
