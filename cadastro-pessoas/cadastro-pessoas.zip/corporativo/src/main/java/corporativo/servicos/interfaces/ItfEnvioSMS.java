package corporativo.servicos.interfaces;

import java.util.List;

public interface ItfEnvioSMS {
	
	public void enviarSMS(List<String> lDestinatarios, String textoMensagem, String chaveCliente);
}
