package corporativo.servicos.interfaces;

public interface ItfConfiguracaoInfraCaptchaCorporativo {
	
	public String getUrlServicoValidar();

}
