package corporativo.servicos.interfaces;

public interface ItfCaptchaCorporativo
{
	public boolean validarCaptcha(String token, String texto, String chaveCliente) throws Throwable;
}
