package br.gov.serpro.cadastro.dominio.integration.intf;

public interface ItfConfiguracaoInfraDneCorporativo {
	
	public String getTrustStore();
	public String getTrustStorePassword();
	public String getDneUrl();
}
