package br.gov.serpro.cadastro.dominio.integration.intf;

public interface ItfDNECorporativo
{
    public String buscarDadosCEP(String cep, String chaveCliente) throws Throwable;
}