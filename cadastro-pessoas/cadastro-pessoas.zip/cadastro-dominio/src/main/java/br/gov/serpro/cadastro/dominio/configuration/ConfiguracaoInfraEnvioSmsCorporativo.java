package br.gov.serpro.cadastro.dominio.configuration;

import br.gov.serpro.cadastro.dominio.integration.intf.ItfConfiguracaoInfraEnvioSms;


public class ConfiguracaoInfraEnvioSmsCorporativo implements ItfConfiguracaoInfraEnvioSms {

	public String getEndPointEnvioSms() {
		return System.getProperty("serpro.gov.br.corporativo.sms.servicos.envio.url");
	}

	public String getChaveAcesso() {
		return System.getProperty("serpro.gov.br.corporativo.sms.chaveAcesso");
	}

}
