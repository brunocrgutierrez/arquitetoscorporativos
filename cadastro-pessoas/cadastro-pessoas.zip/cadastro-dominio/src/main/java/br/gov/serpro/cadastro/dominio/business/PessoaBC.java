package br.gov.serpro.cadastro.dominio.business;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import br.gov.frameworkdemoiselle.stereotype.BusinessController;
import br.gov.frameworkdemoiselle.template.DelegateCrud;
import br.gov.frameworkdemoiselle.util.Beans;
import br.gov.serpro.cadastro.dominio.configuration.ConfiguracoesSms;
import br.gov.serpro.cadastro.dominio.entity.Pessoa;
import br.gov.serpro.cadastro.dominio.integration.intf.ItfEnvioSMS;
import br.gov.serpro.cadastro.dominio.persistence.PessoaDAO;

@BusinessController
public class PessoaBC  extends DelegateCrud<Pessoa, Long, PessoaDAO>  {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5173913986499582065L;

	@Inject
	private ItfEnvioSMS envioSms;
	
	@Inject
	private ConfiguracoesSms configuracoesSms;
	
	@Inject
	private PessoaDAO dao;
	
	@Override
	public Pessoa insert(Pessoa bean) {
		
		
		ItfEnvioSMS envioSms = Beans.getReference(ItfEnvioSMS.class);
		
		Pessoa pessoa = super.insert(bean);
		
		List<String> destinatarios = new ArrayList<String>(0);
		destinatarios.add(bean.getTelefone().getNumero());
		
		envioSms.enviarSMS(destinatarios, "Cadastro efetuado com sucesso!", configuracoesSms.getIdCliente());
		
		return pessoa;
	}
	
	public List<Pessoa> find(String filtro){
		
		return dao.find(filtro);
		
	}
	


}
