package br.gov.serpro.cadastro.dominio.configuration;

import br.gov.serpro.cadastro.dominio.integration.intf.ItfConfiguracaoInfraCaptchaCorporativo;


public class ConfiguracaoInfraCaptchaCorporativo implements ItfConfiguracaoInfraCaptchaCorporativo {

	public String getUrlServicoValidar() {
		return System.getProperty("serpro.gov.br.corporativo.captcha.servicos.validar.url");
	}

}
