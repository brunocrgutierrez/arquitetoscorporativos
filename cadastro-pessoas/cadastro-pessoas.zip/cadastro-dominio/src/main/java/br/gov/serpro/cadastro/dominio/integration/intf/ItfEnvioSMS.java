package br.gov.serpro.cadastro.dominio.integration.intf;

import java.util.List;

public interface ItfEnvioSMS {
	
	public void enviarSMS(List<String> lDestinatarios, String textoMensagem, String chaveCliente);
}
