package br.gov.serpro.cadastro.dominio.integration.intf;

public interface ItfCaptchaCorporativo
{
	public boolean validarCaptcha(String token, String texto, String chaveCliente) throws Throwable;
}
