package br.gov.serpro.cadastro.dominio.entity;

import javax.persistence.Embeddable;

@Embeddable
public abstract class Contato {

}
