package br.gov.serpro.cadastro.dominio.integration.intf;

public interface ItfConfiguracaoInfraCaptchaCorporativo {
	
	public String getUrlServicoValidar();

}
