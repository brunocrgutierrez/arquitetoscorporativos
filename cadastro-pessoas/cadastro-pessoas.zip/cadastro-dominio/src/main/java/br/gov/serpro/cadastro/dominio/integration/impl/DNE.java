package br.gov.serpro.cadastro.dominio.integration.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

import javax.enterprise.inject.spi.BeanManager;
import javax.inject.Inject;
import javax.net.ssl.HttpsURLConnection;

import br.gov.serpro.cadastro.dominio.integration.intf.ItfConfiguracaoInfraDneCorporativo;
import br.gov.serpro.cadastro.dominio.integration.intf.ItfDNECorporativo;


public class DNE implements ItfDNECorporativo
{
	
	@Inject 
	private BeanManager bm;
	
	@Inject
	private ItfConfiguracaoInfraDneCorporativo configuracaoInfraDne;
	
	public String buscarDadosCEP(String cep, String chaveCliente) throws Throwable
	{
		
		String https_url = configuracaoInfraDne.getDneUrl()+cep+"?chave="+chaveCliente;
		URL url = new URL(https_url);
	    HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
		
	    if(con!=null){
			
	    	   BufferedReader br = 
	    		new BufferedReader(
	    			new InputStreamReader(con.getInputStream()));
	    				
	    	   String input;
	    		
	    	   StringBuilder retorno = new StringBuilder();
	    	   while ((input = br.readLine()) != null){
	    		   retorno.append(input);
	    	   }
	    	   br.close();
	    				
	    	   return retorno.toString();
	    }	    			
	    
	    return null;
	}
	
	
}