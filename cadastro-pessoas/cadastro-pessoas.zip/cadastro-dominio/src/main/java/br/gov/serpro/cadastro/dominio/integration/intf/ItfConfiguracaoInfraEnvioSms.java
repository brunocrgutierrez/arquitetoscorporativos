package br.gov.serpro.cadastro.dominio.integration.intf;

public interface ItfConfiguracaoInfraEnvioSms {
	
	public String getEndPointEnvioSms();
	public String getChaveAcesso();
}
