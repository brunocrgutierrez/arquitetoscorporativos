package br.gov.serpro.cadastro.dominio.configuration;

import br.gov.frameworkdemoiselle.annotation.Name;
import br.gov.frameworkdemoiselle.configuration.Configuration;

@Configuration(resource="configuracoessms")
public class ConfiguracoesSms  {

	@Name(value="id.cliente")
	private String idCliente;
	
	public String getIdCliente() {
		return idCliente;
	}

}
