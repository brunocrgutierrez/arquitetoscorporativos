package br.gov.serpro.cadastro.dominio.persistence;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.gov.frameworkdemoiselle.template.JPACrud;
import br.gov.serpro.cadastro.dominio.entity.Pessoa;

public class PessoaDAO extends JPACrud<Pessoa, Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4027119409298291170L;
	
	@Inject
    private EntityManager em;
	
	public List<Pessoa> find(String filter) {
	    StringBuffer jpql = new StringBuffer();
	    jpql.append(" select p ");
	    jpql.append("   from Pessoa p ");
	    jpql.append("  where lower(p.nome) like :filter ");
	    jpql.append("  order by ");
	    jpql.append("        p.nome asc ");
	 
	    TypedQuery<Pessoa> query = em.createQuery(jpql.toString(), Pessoa.class);
	    query.setParameter("filter", "%" + (filter == null ? "" : filter.toLowerCase()) + "%");
	 
	    return query.getResultList();
	}

}
