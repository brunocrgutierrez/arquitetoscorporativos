package br.gov.serpro.cadastro.dominio.exceptions;

public class CaptchaInvalidoException extends Throwable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5621998390782017923L;

	public CaptchaInvalidoException(String message, Throwable cause) {
		super(message, cause);
	}

	public CaptchaInvalidoException(String message) {
		super(message);
	}

	
}
